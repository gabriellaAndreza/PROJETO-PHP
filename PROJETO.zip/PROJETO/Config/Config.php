(config de conexão com o banco de dados)
<?phpreturn [
    'host' => 'localhost',
    'db_name' => 'loja',